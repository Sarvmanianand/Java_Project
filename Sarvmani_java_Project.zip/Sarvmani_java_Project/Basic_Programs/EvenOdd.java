package sarvmanijava_project;

import java.util.Scanner;

public class EvenOdd {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int number=sc.nextInt();
		System.out.println("Enter your no. here");
		if(number%2==0){
			System.out.println("Even");
		}
		else
			System.out.println("Odd");
		
	}

}
