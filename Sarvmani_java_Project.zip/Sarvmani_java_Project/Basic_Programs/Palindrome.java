package sarvmanijava_project;

import java.util.Scanner;

public class Palindrome {public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter your no. here");

	int num=sc.nextInt(),rev=0,rem,temp;
	temp=num;
	while(temp>0) {
		rem =temp%10;
		rev=rev*10+rem;
		temp=temp/10;
	}
	if (num==rev) 
		System.out.println("Is palindrome");
	else
		System.out.println("Is not Palindrome");


}




}
