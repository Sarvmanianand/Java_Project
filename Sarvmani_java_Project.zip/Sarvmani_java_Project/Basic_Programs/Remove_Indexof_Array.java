package sarvmanijava_project;

import java.util.Arrays;

public class Remove_Indexof_Array {
	public static int[] removeElement(int[]arr,int index) {
		if (arr==null || index<0||index >=arr.length) {
			return arr;
		}
		int[]anotherArray= new int[arr.length-1];
		for (int i=0,k=0;i<arr.length;i++) {
			if(i==index) {
				continue;
			}
			else 
				 anotherArray[k++]=arr[i];
		}
		return anotherArray;

	}

	public static void main(String[] args) {
		int[] arr= {1,3,4,5,6,7,9,8,9,9,};
		System.out.println("Original Array: "+Arrays.toString(arr));
		int index=2;
		System.out.println("Index to be removed: "+index);
		arr =removeElement(arr,index);
		System.out.println("Resultant Array: "+Arrays.toString(arr) );

	}

}
