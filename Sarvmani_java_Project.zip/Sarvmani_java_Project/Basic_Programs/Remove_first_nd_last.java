package sarvmanijava_project;

public class Remove_first_nd_last {

	public static void main(String[] args) 
	{
	String	str="Edubridge";
	
     str=str.substring(1,str.length()-1);
     
     System.out.println(str);
	}

}
