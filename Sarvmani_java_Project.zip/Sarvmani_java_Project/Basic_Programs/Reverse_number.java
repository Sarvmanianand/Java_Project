package sarvmanijava_project;

public class Reverse_number 
{
	public static void main (String []argd) {
		int n=258798;
		int rev=0;
		int rem;
		while (n>0) {
			rem=n%10;
			rev=rev*10+rem;
			n = n/10;
		}
		System.out.println(rev);
		
	}

}
