package oopsConcepts;

class Vehicle 
{
    public void start () 
    {
        System.out.println ("Vehicle started");
    }
    public void stop () 
    {
        System.out.println ("Vehicle stopped");
    }
}

class Car extends Vehicle
{
    public void openDoor() 
    {
        System.out.println("Car door opened");
    }
    public void closeDoor() 
    {
        System.out.println("Car door closed");
    }
}

public class Hybrid_Inheritance extends Car
{
    public void turboBoost() 
    {
        System.out.println("Turbo boost activated");
    }
    public void nitroBoost() 
    {
        System.out.println("Nitro boost activated");
    }
    public static void main(String args[])
    {
        Hybrid_Inheritance obj = new Hybrid_Inheritance();
        obj.start();
        obj.openDoor();
        obj.turboBoost();
        obj.nitroBoost();
        obj.stop();
    }
}
