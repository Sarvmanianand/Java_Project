package oopsConcepts;

class Parent 
{
	public void div(int a, int b)
	{
		System.out.println("Quotient: "+(a/b));
	}
}
class Child
{
	public void div(int a, int b)
	{
		System.out.println("Quotient: "+(a/b));
		System.out.println("Remainder:"+(a%b));
	}
}
public class Method_OverRiding
{

	public static void main(String[] args)
	{
		Child c=new Child();
		c.div(21, 2);
	}

}